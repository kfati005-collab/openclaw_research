# -*- coding: utf-8 -*-

!pip install -q transformers datasets accelerate evaluate scikit-learn openpyxl

!pip uninstall -y torchvision
!pip install -q torchvision==0.20.1
!pip install -q transformers==4.46.3 datasets==3.1.0 accelerate==1.1.1 evaluate==0.4.3

"""**Import Libraries**"""

import pandas as pd
import numpy as np
import torch

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

from datasets import Dataset

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer
)

"""**Upload Dataset**"""

from google.colab import drive
drive.mount('/content/drive')

INPUT_FILE = "/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier/all_850_for_train.xlsx"

"""**Load Dataset**"""

df = pd.read_excel(INPUT_FILE)

print(df.head())

print(df.columns)

"""**Check Missing Values**"""

print(df.isnull().sum())

df = df.fillna("")

"""**Combine Title and Body**"""

df["text"] = df["Title"] + " [SEP] " + df["Body"]

df = df[["text","label"]]

df.head()

"""**Check Class Distribution**"""

print(df.dtypes)
print(df["label"].unique())
print(df["label"].value_counts(dropna=False))

# Remove leading/trailing spaces
df["label"] = df["label"].astype(str).str.strip()

# Convert to numeric (invalid values become NaN)
df["label"] = pd.to_numeric(df["label"], errors="coerce")

# Remove rows with invalid labels
df = df.dropna(subset=["label"])

# Convert labels to integers
df["label"] = df["label"].astype(int)

# Verify
print(df["label"].value_counts())

"""**Train/Test Split**"""

train_df, test_df = train_test_split(
    df,
    test_size=0.2,
    stratify=df["label"],
    random_state=42
)

print("Training:", len(train_df))
print("Testing :", len(test_df))

"""**Convert to HuggingFace Dataset**"""

train_dataset = Dataset.from_pandas(train_df)
test_dataset = Dataset.from_pandas(test_df)

"""**Load BERT Tokenizer**"""

model_name = "bert-base-uncased"

tokenizer = AutoTokenizer.from_pretrained(model_name)

"""**Tokenize**"""

def tokenize(batch):
    return tokenizer(
        batch["text"],
        padding="max_length",
        truncation=True,
        max_length=256
    )

train_dataset = train_dataset.map(tokenize, batched=True)
test_dataset = test_dataset.map(tokenize, batched=True)

"""**Format Dataset**"""

train_dataset.set_format(
    type="torch",
    columns=["input_ids","attention_mask","label"]
)

test_dataset.set_format(
    type="torch",
    columns=["input_ids","attention_mask","label"]
)

"""**Load BERT Model**"""

model = AutoModelForSequenceClassification.from_pretrained(
    model_name,
    num_labels=2
)

"""**Evaluation Metrics**"""

def compute_metrics(eval_pred):

    logits, labels = eval_pred

    predictions = np.argmax(logits, axis=-1)

    precision, recall, f1, _ = precision_recall_fscore_support(
        labels,
        predictions,
        average="binary"
    )

    accuracy = accuracy_score(labels, predictions)

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }

"""**Training Arguments**"""

training_args = TrainingArguments(

    output_dir="./results",

    eval_strategy="epoch",

    save_strategy="epoch",

    learning_rate=1e-5,

    per_device_train_batch_size=8,

    per_device_eval_batch_size=8,

    num_train_epochs=10,

    weight_decay=0.01,
    warmup_ratio=0.1,
    lr_scheduler_type="linear",

    load_best_model_at_end=True,

    metric_for_best_model="f1",

    logging_dir="./logs",

    logging_steps=10,
    report_to="none"

)

"""**Create Trainer**"""

trainer = Trainer(

    model=model,

    args=training_args,

    train_dataset=train_dataset,

    eval_dataset=test_dataset,

    compute_metrics=compute_metrics,
)

"""**Train the Model**"""

trainer.train()

"""**Evaluate**"""

results = trainer.evaluate()

print(results)

"""**Save the Model**"""

trainer.save_model("security_classifier")

tokenizer.save_pretrained("security_classifier")