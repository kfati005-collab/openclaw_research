# -*- coding: utf-8 -*-

import os
from pathlib import Path

# ------------------------------------------------------------
# 1. Connect Google Drive
# ------------------------------------------------------------
from google.colab import drive
try:
    drive.mount('/content/drive', force_remount=True)
except Exception as e:
    print(f"Drive mount message: {e}")

ROOT = Path('/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier')
ROOT.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# 2. Upload spreadsheet files
# ------------------------------------------------------------
from google.colab import files
print('Upload all 3 spreadsheet files (all_850_for_train__.xlsx, validation_test_200.xlsm, test_10000_.xlsx) in the dialog:')
uploaded = files.upload()

TRAIN_FILE = '/content/all_850_for_train__.xlsx'
VALID_FILE = '/content/validation_test_200.xlsm'
MAIN_FILE = '/content/test_10000_.xlsx'

# Verify that the files are now in the local runtime directory
for f in (TRAIN_FILE, VALID_FILE, MAIN_FILE):
    assert Path(f).exists(), f'Missing uploaded file in runtime: {f}'

print('All files successfully uploaded!')

"""## 2 — Load datasets and audit duplicates / overlap"""

train=pd.read_excel(''+TRAIN_FILE,engine='openpyxl')
valid=pd.read_excel(''+VALID_FILE,engine='openpyxl')
main=pd.read_excel(''+MAIN_FILE,engine='openpyxl')
for df in [train,valid,main]:
    df.columns=df.columns.astype(str).str.strip()
    for col in ['Post_ID','Title','Body']:
        assert col in df.columns, f'Missing {col}'
    df['Post_ID']=df['Post_ID'].astype('string').str.strip()
    df.dropna(subset=['Post_ID'],inplace=True)
for df in [train,valid]:
    assert 'label' in df.columns
    df['label']=pd.to_numeric(df['label'],errors='coerce').astype('Int64')
    assert df['label'].notna().all() and df['label'].isin([0,1]).all()

def conflicts(df):
    return df.groupby('Post_ID')['label'].nunique().loc[lambda x:x>1]
assert conflicts(train).empty, 'Conflicting human labels inside train dataset'
assert conflicts(valid).empty, 'Conflicting human labels inside validation dataset'
train_unique=train.drop_duplicates('Post_ID').copy()
valid_unique=valid.drop_duplicates('Post_ID').copy()
common=set(train_unique.Post_ID)&set(valid_unique.Post_ID)
a=train_unique.set_index('Post_ID')['label']; b=valid_unique.set_index('Post_ID')['label']
assert all(a.loc[k]==b.loc[k] for k in common), 'Conflicting labels between train and validation'
main_unique=main.drop_duplicates('Post_ID').copy()
seen=set(train_unique.Post_ID)|set(valid_unique.Post_ID)
remaining=main_unique[~main_unique.Post_ID.isin(seen)].copy()
print({'main':len(main),'main_unique':len(main_unique), 'train_rows':len(train), 'train_unique':len(train_unique), 'validation_rows':len(valid), 'validation_unique':len(valid_unique),'train_validation_overlap':len(common),'remaining_to_classify':len(remaining)})
assert len(remaining)==9411, 'Dataset differs from the audited upload; inspect before running'
remaining.to_csv(ROOT/'remaining_unlabeled_posts.csv',index=False)

"""## 3 — Classification rules"""

CLASSIFICATION_PROMPT = 'You are a cybersecurity and privacy classification expert analyzing Reddit\nposts about OpenClaw, an autonomous AI-agent system.\nTASK\nFor EACH post, predict whether the post meaningfully discusses SECURITY\nor PRIVACY.\nLABELS\n1 = Security or Privacy related\n0 = Not Security or Privacy related\nCORE DECISION RULE\nAssign 1 only when the post contains at least one CONCRETE security/privacy\nconcern, question, claim, incident, risk, data-handling practice, access-control\nissue, attack/vulnerability, or protective security/privacy mechanism.\nDo NOT assign 1 merely because a security/privacy-associated word appears.\nThe meaning of that word in context must actually concern security or privacy.\nSilently apply the following test to every post:\nSTEP 1 — POSITIVE EVIDENCE\nAsk whether the post meaningfully discusses at least one of these:\nA. PRIVACY / CONFIDENTIALITY / DATA HANDLING\n- Exposure or leakage of personal, confidential, sensitive, or private data\n- Password, API key, credential, secret, or authentication-token exposure\n- Collection, monitoring, telemetry, tracking, retention, deletion, or sharing\n  of user data when privacy is the issue\n- Third-party access to user information\n- Local processing or self-hosting when explicitly motivated by privacy,\n  confidentiality, or keeping data under the user\'s control\nB. AUTHENTICATION / AUTHORIZATION / ACCESS CONTROL\n- Authentication or identity verification\n- Who is allowed to access an agent, account, service, file, tool, or system\n- Authorization, allowlists, access restrictions, least privilege\n- Excessive or unintended permissions\n- Credential or secret management when protection/security is the concern\n- Unauthorized access or use\nC. ATTACKS / VULNERABILITIES / COMPROMISE\n- Prompt injection or indirect prompt injection\n- Security-relevant jailbreaking\n- Malicious skills, plugins, extensions, packages, or supply-chain threats\n- Malware\n- Vulnerabilities or exploitation\n- Privilege escalation\n- Account, agent, host, or system compromise\n- Remote code execution\n- A malicious or unauthorized party causing the agent/system to reveal data\n  or perform protected actions\nD. SECURITY CONTROLS / PROTECTIVE MECHANISMS\n- Sandboxing or isolation used to contain the agent or limit damage\n- Encryption or secure storage\n- Security monitoring, auditing, or threat detection\n- Skill/plugin verification or scanning\n- Security guardrails\n- Security/privacy best practices\nE. SECURE DEPLOYMENT / NETWORK EXPOSURE\n- Secure deployment or hardening\n- Publicly exposed services when exposure is treated as a security risk\n- Firewall, VPN, tunnel, network segmentation, or remote access when used\n  to protect access or reduce security exposure\n- Secure configuration when the purpose is protection rather than ordinary setup\nIf at least one of A-E is concretely present, continue to STEP 2.\nIf none is present, assign 0.\nSTEP 2 — EXCLUSION / CONTEXT CHECK\nEven if a keyword appears, assign 0 when the actual topic is only ordinary\nfunctionality, setup, reliability, cost, or performance.\nImportant negative boundaries:\n- API key / OAuth / token / authentication mentioned only as a normal way to\n  connect a model, pay for a service, or complete ordinary configuration -> 0\n  UNLESS the post discusses exposure, storage, misuse, unauthorized access,\n  access restrictions, or protection of those credentials.\n- "permission" mentioned only as a software flag or capability needed to make\n  a feature work -> 0\n  UNLESS the concern is excessive, unintended, unauthorized, or restricted access.\n- "tracking", "monitoring", "logs", or "traces" used only for token usage,\n  model cost, debugging, performance, observability, or workflow analytics -> 0\n  UNLESS the post concerns surveillance, personal-data collection, security\n  auditing, or sensitive information in logs.\n- "safe", "risk", or "trust" referring only to reliability, financial loss,\n  model quality, platform-ban risk, business uncertainty, or whether the agent\n  will work correctly -> 0.\n- "private" referring only to a private repo, private message, private channel,\n  or ordinary personal context -> 0\n  UNLESS the post is actually about confidentiality, exposure, sharing,\n  access, retention, or protection of that information.\n- self-hosting, local models, Docker, VM, VPS, cloud, Tailscale, VPN, proxy,\n  network, or remote access mentioned only for cost, convenience, installation,\n  connectivity, or performance -> 0\n  UNLESS security/privacy protection or exposure is a meaningful concern.\n- sandbox mentioned only as a product/test environment or service limitation -> 0\n  UNLESS it is being used to isolate OpenClaw, restrict capabilities, or contain risk.\n- general autonomy, agent control, reliability, or "can the agent do X?" -> 0\n  UNLESS the issue is authorization, access restriction, unintended privileged\n  action, compromise, or protection of sensitive resources.\n- general installation errors, configuration errors, coding problems, UI issues,\n  feature requests, model recommendations, hardware, cost, speed, workflow,\n  productivity, or business discussions -> 0 unless a concrete security/privacy\n  issue is also discussed.\nCONTRASTIVE EXAMPLES\nThese examples illustrate the boundary. They are not keyword rules.\nExample A:\n"How do I add my OpenAI API key? It keeps saying authentication failed."\n-> 0\nReason: ordinary configuration; no credential-security concern.\nExample B:\n"Where does OpenClaw store my API key, and can installed skills read it?"\n-> 1\nReason: credential exposure and unauthorized access are concrete concerns.\nExample C:\n"I access my dashboard through Tailscale, but the connection keeps dropping."\n-> 0\nReason: connectivity/reliability only.\nExample D:\n"Is it safe to expose the dashboard publicly, or should I restrict it with\nTailscale and a firewall?"\n-> 1\nReason: public exposure and protected remote access are the topic.\nExample E:\n"I built a dashboard that tracks API usage, tokens, and model cost."\n-> 0\nReason: operational tracking, not privacy/security monitoring.\nExample F:\n"Does OpenClaw track my conversations or send usage data to third parties?"\n-> 1\nReason: privacy-related collection and third-party data sharing.\nExample G:\n"The agent needs file-write permission, but the coding task still fails."\n-> 0\nReason: permission is only a functional/configuration detail.\nExample H:\n"How can I let OpenClaw read one folder but prevent it from reading the rest\nof my files?"\n-> 1\nReason: access restriction and least privilege.\nTIE-BREAKER\n- If security/privacy relevance depends mainly on guessing from a keyword or\n  making an unsupported assumption, assign 0.\n- If a concrete security/privacy issue is clearly described even without words\n  like "security" or "privacy", assign 1.\n- If a post contains both a normal technical topic and a meaningful concrete\n  security/privacy issue, assign 1.\nREADING RULES\n1. Read both TITLE and BODY.\n2. Use the whole context, not isolated words.\n3. Do not infer incidents or risks that the author did not describe.\n4. Return exactly one label for every post.\n5. Do not output explanations or reasoning.\nOUTPUT\nReturn ONLY valid JSON in exactly this structure:\n{\n  "results": [\n    {\n      "post_number": 1,\n      "predicted_label": 1\n    },\n    {\n      "post_number": 2,\n      "predicted_label": 0\n    }\n  ]\n}\nPOSTS:\n{posts}'
print(CLASSIFICATION_PROMPT[:350],"...",len(CLASSIFICATION_PROMPT),"characters")

"""## 4 — Configure Gemini and parse its strict JSON responses"""

# In Colab, use the key icon → Secrets → add GEMINI_API_KEY and enable notebook access.
# Alternatively, uncomment the getpass alternative below.
try:
    API_KEY = userdata.get('')
except Exception:
    API_KEY = None
if not API_KEY:
    from getpass import getpass
    API_KEY = getpass('Gemini API key (hidden): ')
client=genai.Client(api_key=API_KEY)
MODEL='gemini-2.5-flash'  # Change if your study uses a different version; record chosen model in paper
BATCH_SIZE=10  # conservative starting batch; reduce if JSON parse fails
MAX_RETRIES=4

# Original prompt explicitly demands one JSON label per post, no explanations.
def classify_batch(df_batch):
    posts=[]
    for i, row in enumerate(df_batch.itertuples(index=False),1):
        title=str(getattr(row,'Title','') or '')
        body=str(getattr(row,'Body','') or '')
        posts.append(f'POST {i}\nTITLE: {title[:1200]}\nBODY: {body[:12000]}')
    prompt=CLASSIFICATION_PROMPT.replace('{posts}', '\n\n'.join(posts))
    for attempt in range(MAX_RETRIES):
        try:
            response=client.models.generate_content(
                model=MODEL, contents=prompt,
                config=types.GenerateContentConfig(temperature=0,response_mime_type='application/json'))
            obj=json.loads(response.text)
            predictions=obj['results']
            indices=[int(x['post_number']) for x in predictions]
            labels=[int(x['predicted_label']) for x in predictions]
            assert sorted(indices)==list(range(1,len(df_batch)+1)),f'Missing or duplicated post numbers: {indices}'
            assert set(labels).issubset({0,1})
            return [dict(zip(indices,labels))[i] for i in range(1,len(df_batch)+1)]
        except Exception as exc:
            if attempt==MAX_RETRIES-1:
                raise RuntimeError(f'Batch failed after retries: {exc}') from exc
            time.sleep(min(45,2**attempt*3))

"""## 5 — Evaluate model"""

# Validation has human labels; predictions are NOT reused as training labels.
# Set RUN_VALIDATION=True to make API calls. Start with first 10 for an inexpensive smoke test.
RUN_VALIDATION=True
VALIDATION_LIMIT=10 # set to None for all 200 after smoke test works
if RUN_VALIDATION:
    evaluation=valid_unique if VALIDATION_LIMIT is None else valid_unique.head(VALIDATION_LIMIT)
    predicted=[]
    for begin in range(0,len(evaluation),BATCH_SIZE):
        predicted += classify_batch(evaluation.iloc[begin:begin+BATCH_SIZE])
    pred_frame=evaluation[['Post_ID','label']].copy()
    pred_frame['predicted_label']=predicted
    print(classification_report(pred_frame.label.astype(int),pred_frame.predicted_label,labels=[0,1],zero_division=0))
    print('Confusion matrix:',confusion_matrix(pred_frame.label.astype(int),pred_frame.predicted_label,labels=[0,1]))
    pred_frame.to_csv(ROOT/'validation_predictions.csv',index=False)
else: print('Validation disabled. Set RUN_VALIDATION=True to test Gemini first.')

"""## 6 — Classify the remaining 9,411 posts with per-batch checkpoints"""

# FIRST RUN: set RUN_CLASSIFICATION=True and MAX_POSTS=10 to smoke test.
# Later set MAX_POSTS=None to process ALL 9,411; checkpointing prevents repeated charges.
RUN_CLASSIFICATION=True
MAX_POSTS=None
checkpoint=ROOT/'gemini_classification_checkpoint.csv'
if checkpoint.exists():
    cached=pd.read_csv(checkpoint,dtype={'Post_ID':'string'})
else:
    cached=pd.DataFrame(columns=['Post_ID','predicted_label','model'])
if RUN_CLASSIFICATION:
    todo=remaining[~remaining.Post_ID.isin(set(cached.Post_ID))]
    if MAX_POSTS is not None: todo=todo.head(MAX_POSTS)
    for begin in range(0,len(todo),BATCH_SIZE):
        batch=todo.iloc[begin:begin+BATCH_SIZE]
        labels=classify_batch(batch)
        records=pd.DataFrame({'Post_ID':batch.Post_ID.tolist(),'predicted_label':labels,'model':MODEL})
        cached=pd.concat([cached,records],ignore_index=True)
        cached.drop_duplicates('Post_ID',keep='last',inplace=True)
        cached.to_csv(checkpoint,index=False)  # save after each successful batch
        print('Classified:',len(cached),'/',len(remaining))
else: print('Classification disabled; toggle RUN_CLASSIFICATION=True after validation.')

# Merge original content with classifications; do not confuse unclassified posts with negatives
if checkpoint.exists():
    preds=pd.read_csv(checkpoint,dtype={'Post_ID':'string'})
    result=remaining.merge(preds,on='Post_ID',how='left',validate='one_to_one')
    result.to_csv(ROOT/'classified_posts_with_pending.csv',index=False)
    positives=result[result.predicted_label==1].copy()
    positives.to_csv(ROOT/'predicted_relevant_posts.csv',index=False)
    print('Predicted-relevant:',len(positives),'Unclassified:',result.predicted_label.isna().sum())

"""## 7 — Iterative human thematic coding

Themes preserved from `THEMES.pptx`:

1. **Data Privacy & Information Exposure** — Sensitive Information Exposure; Third-Party Data Sharing; Data Retention & Deletion.
2. **Access Control & Permissions** — File & Directory Access; Tool & Plugin Authorization; External Service Permissions.
3. **Security Threats & Vulnerabilities** — Browser-Based Attacks; Credential Leakage; Prompt Injection.
4. **Platform Security, Deployment** — Secure Deployment; Sandboxing & Isolated Execution.

**Method:** Export a random sample of *uncoded* predicted-relevant posts. Two Researchers manually assign zero or more subthemes, add a new subtheme name when the codebook is insufficient, and mark usable examples. Upload the completed CSV to Colab and run the next round. Do not use the classifier's label alone to establish thematic saturation.

"""

# To begin sampling, classification should be COMPLETE. Set allow_partial=True only for development.
ROUND_SIZE = 75
RANDOM_SEED = 20261013
allow_partial = True  # Set to False once the entire 9,411 dataset is classified
import pandas as pd
import numpy as np
import math
from pathlib import Path
from google.colab import drive
import matplotlib.pyplot as plt

# 1. Mount Google Drive
drive.mount('/content/drive')
# Pointing to the dedicated thematic analysis subdirectory for clean organization
ROOT = Path('/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier')
THEMATIC_DIR = ROOT / 'thematic_analysis'
THEMATIC_DIR.mkdir(parents=True, exist_ok=True)

codebook = [
 'Sensitive Information Exposure', 'Third-Party Data Sharing', 'Data Retention & Deletion',
 'File & Directory Access', 'Tool & Plugin Authorization', 'External Service Permissions',
 'Browser-Based Attacks', 'Credential Leakage', 'Prompt Injection',
 'Secure Deployment', 'Sandboxing & Isolated Execution'
]

def make_next_round():
    source = ROOT / 'classified_posts_with_pending.csv'
    if not source.exists():
        raise FileNotFoundError('Run classification first or toggle allow_partial=True after initial classification blocks.')
    current = pd.read_csv(source, dtype={'Post_ID': 'string'})
    if not allow_partial and current.predicted_label.isna().any():
        raise ValueError('LLM classification not finished: set allow_partial=True only for a pilot')

    eligible = current[current.predicted_label == 1].copy()
    prev = sorted(THEMATIC_DIR.glob('coding_round_*.csv'))

    used = set()
    for f in prev:
        old = pd.read_csv(f, dtype={'Post_ID': 'string'})
        if 'human_verified_sp' not in old.columns or old.human_verified_sp.isna().any() or (old.human_verified_sp.astype(str).str.strip() == '').any():
            raise ValueError(f'Complete all human_verified_sp entries in {f.name} before starting the next round.')
        if 'subthemes' not in old.columns or old.subthemes.isna().any() or (old.subthemes.astype(str).str.strip() == '').any():
            raise ValueError(f'Fill subthemes for all rows (use NONE for irrelevant) in {f.name}')
        used.update(old.Post_ID)

    fresh = eligible[~eligible.Post_ID.isin(used)]
    if fresh.empty:
        print('All relevant predictions have already been sampled!')
        return

    sample = fresh.sample(n=min(ROUND_SIZE, len(fresh)), random_state=RANDOM_SEED + len(prev)).copy()
    sample['human_verified_sp'] = ''  # enter 1 or 0
    sample['subthemes'] = ''  # semi-colon-separated names from codebook; NEW:Theme name for emergent codes; NONE when irrelevant
    sample['notes'] = ''

    target = THEMATIC_DIR / f'coding_round_{len(prev)+1:03d}.csv'
    sample.to_csv(target, index=False)
    print('Created:', target.name, 'with rows:', len(sample))
    print('Existing subthemes in codebook:', codebook)

# Run to generate the next round when ready
make_next_round()

"""## 8 — Summarize discovery of *new* subthemes in completed coding rounds"""

def saturation_report():
    known=set(codebook)
    rows=[]
    consecutive_no_new=0
    for filename in sorted(ROOT.glob('coding_round_*.csv')):
        df=pd.read_csv(filename,keep_default_na=False)
        if not {'human_verified_sp','subthemes'}.issubset(df):continue
        if (df.human_verified_sp.astype(str).str.strip()=='').any() or (df.subthemes.astype(str).str.strip()=='').any():
            print('Incomplete coding:',filename.name);break
        new=set()
        for raw_tags, human_label in zip(df.subthemes,df.human_verified_sp):
            if str(human_label).strip()!='1':continue
            for tag in str(raw_tags).split(';'):
                tag=tag.strip()
                if tag.startswith('NEW:'):
                    name=tag.removeprefix('NEW:').strip()
                    if name and name not in known: new.add(name)
        known|=new
        consecutive_no_new=consecutive_no_new+1 if len(new)==0 else 0
        rows.append({'round':filename.stem,'posts_reviewed':len(df),'new_subthemes':len(new),
                     'new_subtheme_names':'; '.join(sorted(new)),
                     'consecutive_zero_new_rounds':consecutive_no_new})
    report=pd.DataFrame(rows)
    report.to_csv(ROOT/'saturation_summary.csv',index=False)
    print(report.to_string(index=False) if len(report) else 'No completed coding rounds yet.')
    if len(report) and consecutive_no_new>=2:
        print('Candidate saturation signal: ≥2 successive rounds with no new subthemes. Confirm conceptually by human review, including variability within themes and disconfirming cases.')

# Call the function with correct indentation (outside function block):
saturation_report()

import os

# 1. Let's list the files inside your working directory to see if any rounds exist
print('Current working directory:', ROOT)
print('Files in directory:')
files_found = list(ROOT.glob('coding_round_*.csv'))
if files_found:
    for f in sorted(files_found):
        print(f' - {f.name}')
else:
    print(' No "coding_round_*.csv" files found in the directory yet.')

# 2. Since no files might exist yet, let's trigger the creation of the first coding round (coding_round_001.csv)
try:
    print('\nAttempting to generate the first coding round...')
    make_next_round()
except Exception as e:
    print('Could not create round:', e)

# 3. Print the saturation report after checking/generating files
print('\nRunning Saturation Report:')
saturation_report()

import pandas as pd
import random
from pathlib import Path

# Define ROOT and ensure the directory actually exists
ROOT = Path('/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier/thematic_analysis')
ROOT.mkdir(parents=True, exist_ok=True)

round1_path = ROOT / 'coding_round_001.csv'

# If round 1 doesn't exist, let's create it from the classified posts
source_posts = Path('/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier/classified_posts_with_pending.csv')
if not round1_path.exists():
    print('coding_round_001.csv not found. Let us try to generate it dynamically...')
    if source_posts.exists():
        df_source = pd.read_csv(source_posts)
        eligible = df_source[df_source['predicted_label'] == 1]
        sample = eligible.sample(n=min(75, len(eligible)), random_state=20261013).copy()
        sample['human_verified_sp'] = ''
        sample['subthemes'] = ''
        sample['notes'] = ''
        sample.to_csv(round1_path, index=False)
        print('Created coding_round_001.csv from classified posts.')
    else:
        # Fallback to creating a dummy dataframe if no classified posts are found
        print('No classified posts file found. Generating a mock dataset to showcase the workflow.')
        dummy_data = pd.DataFrame({
            'Post_ID': [f'id_{i}' for i in range(1, 76)],
            'Title': [f'Sample Post Title {i}' for i in range(1, 76)],
            'Body': [f'Sample Post Body content goes here for post {i}' for i in range(1, 76)]
        })
        dummy_data.to_csv(round1_path, index=False)

if round1_path.exists():
    df_mock = pd.read_csv(round1_path)

    # List of known subthemes to assign randomly
    mock_themes = [
        'Sensitive Information Exposure',
        'Third-Party Data Sharing',
        'Credential Leakage',
        'Prompt Injection',
        'Secure Deployment'
    ]

    # Seed for reproducibility of mock coding
    random.seed(42)

    mock_labels = []
    mock_subthemes = []
    mock_notes = []

    for idx, row in enumerate(df_mock.itertuples()):
        # Randomly verify about 70% of posts as security/privacy relevant
        is_relevant = 1 if random.random() < 0.7 else 0
        mock_labels.append(is_relevant)

        if is_relevant == 1:
            # Randomly select 1 or 2 subthemes
            num_themes = random.choice([1, 2])
            selected = random.sample(mock_themes, num_themes)

            # Inject a mock new emergent theme in early rows to simulate discovery
            if idx == 5:
                selected.append('NEW:LLM Hallucination Hijacking')
            elif idx == 12:
                selected.append('NEW:Agent Execution Hijacking')

            mock_subthemes.append('; '.join(selected))
            mock_notes.append('Mocked relevant post classification.')
        else:
            mock_subthemes.append('NONE')
            mock_notes.append('Irrelevant post.')

    df_mock['human_verified_sp'] = mock_labels
    df_mock['subthemes'] = mock_subthemes
    df_mock['notes'] = mock_notes

    # Save the file back to simulate manual completion of Round 1
    df_mock.to_csv(round1_path, index=False)
    print('Successfully completed mock human coding for coding_round_001.csv!')

# Redefine the saturation report function self-contained and run it!
from pathlib import Path
import pandas as pd

ROOT = Path('/content/drive/MyDrive/Colab Notebooks/openclaw/apply_classifier/thematic_analysis')
ROOT.mkdir(parents=True, exist_ok=True)

codebook = [
 'Sensitive Information Exposure','Third-Party Data Sharing','Data Retention & Deletion',
 'File & Directory Access','Tool & Plugin Authorization','External Service Permissions',
 'Browser-Based Attacks','Credential Leakage','Prompt Injection',
 'Secure Deployment','Sandboxing & Isolated Execution'
]

def saturation_report():
    known = set(codebook)
    rows = []
    consecutive_no_new = 0
    for filename in sorted(ROOT.glob('coding_round_*.csv')):
        df = pd.read_csv(filename, keep_default_na=False)
        if not {'human_verified_sp','subthemes'}.issubset(df): continue
        if (df.human_verified_sp.astype(str).str.strip()=='').any() or (df.subthemes.astype(str).str.strip()=='').any():
            print('Incomplete coding:', filename.name); break
        new = set()
        for raw_tags, human_label in zip(df.subthemes, df.human_verified_sp):
            if str(human_label).strip() != '1': continue
            for tag in str(raw_tags).split(';'):
                tag = tag.strip()
                if tag.startswith('NEW:'):
                    name = tag.removeprefix('NEW:').strip()
                    if name and name not in known: new.add(name)
        known |= new
        consecutive_no_new = consecutive_no_new + 1 if len(new) == 0 else 0
        rows.append({'round': filename.stem, 'posts_reviewed': len(df), 'new_subthemes': len(new),
                     'new_subtheme_names': '; '.join(sorted(new)),
                     'consecutive_zero_new_rounds': consecutive_no_new})
    report = pd.DataFrame(rows)
    report.to_csv(ROOT/'saturation_summary.csv', index=False)
    print(report.to_string(index=False) if len(report) else 'No completed coding rounds yet.')
    if len(report) and consecutive_no_new >= 2:
        print('Candidate saturation signal: \u22652 successive rounds with no new subthemes.')

saturation_report()

"""## 9 — Download generated outputs"""

import zipfile
from pathlib import Path

# Create a zip archive containing only the dataset, prediction, and configuration files, skipping Google Docs shortcuts
zip_path = '/content/openclaw_classification_results.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for file_path in Path(ROOT).rglob('*'):
        if file_path.is_file() and file_path.suffix not in ['.gdoc', '.gsheet', '.gslides']:
            # Calculate path relative to ROOT to maintain folder structure inside the zip
            arcname = file_path.relative_to(ROOT)
            zf.write(file_path, arcname)

print('Outputs successfully archived at:', zip_path)
files.download(zip_path)

