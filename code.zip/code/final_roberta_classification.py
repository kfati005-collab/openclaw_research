# -*- coding: utf-8 -*-


!pip install -q transformers datasets accelerate sentencepiece evaluate

#!pip uninstall -y torchvision
#!pip install -q torchvision==0.20.1
#!pip install -q transformers==4.46.3 datasets==3.1.0 accelerate==1.1.1 evaluate==0.4.3

!pip uninstall -y torchvision

!pip install -q transformers==4.46.3 \
    datasets==3.1.0 \
    accelerate==1.1.1 \
    evaluate==0.4.3

"""**Import Libraries**"""

import pandas as pd
import numpy as np
import torch

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

from datasets import Dataset

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer
)

"""**Upload Dataset**"""

from google.colab import drive
drive.mount('/content/drive')

INPUT_FILE = "/content/drive/MyDrive/all_850_for_train.xlsx"

"""**Load Dataset**"""

df = pd.read_excel(INPUT_FILE)

print(df.head())

print(df.columns)

"""**Check Missing Values**"""

print(df.isnull().sum())

df = df.fillna("")

"""**Combine Title and Body**"""

df["text"] = df["Title"] + " [SEP] " + df["Body"]

df = df[["text","label"]]

df.head()

"""**Check Class Distribution**"""

print(df.dtypes)
print(df["label"].unique())
print(df["label"].value_counts(dropna=False))

# Remove leading/trailing spaces
df["label"] = df["label"].astype(str).str.strip()

# Convert to numeric (invalid values become NaN)
df["label"] = pd.to_numeric(df["label"], errors="coerce")

# Remove rows with invalid labels
df = df.dropna(subset=["label"])

# Convert labels to integers
df["label"] = df["label"].astype(int)

# Verify
print(df["label"].value_counts())

"""**Train/Test Split**"""

from sklearn.model_selection import train_test_split

# 70% train, 30% temporary
train_df, temp_df = train_test_split(
    df,
    test_size=0.30,
    stratify=df["label"],
    random_state=42
)

# Split temporary data into 15% validation and 15% test
val_df, test_df = train_test_split(
    temp_df,
    test_size=0.50,
    stratify=temp_df["label"],
    random_state=42
)

print("Train:", len(train_df))
print("Validation:", len(val_df))
print("Test:", len(test_df))

"""**Convert to HuggingFace Dataset**"""

train_dataset = Dataset.from_pandas(train_df)
test_dataset = Dataset.from_pandas(test_df)
val_dataset = Dataset.from_pandas(val_df,
    preserve_index=False
)

"""**Load RoBERTa Tokenizer**"""

model_name = "roberta-base"

tokenizer = AutoTokenizer.from_pretrained(model_name)

"""**Tokenize**"""

def tokenize(batch):
    return tokenizer(
        batch["text"],
        padding="max_length",
        truncation=True,
        max_length=384
    )

train_dataset = train_dataset.map(tokenize, batched=True)
test_dataset = test_dataset.map(tokenize, batched=True)
val_dataset = val_dataset.map(tokenize,batched=True)

"""**Format Dataset**"""

train_dataset.set_format(
    type="torch",
    columns=["input_ids","attention_mask","label"]
)

test_dataset.set_format(
    type="torch",
    columns=["input_ids","attention_mask","label"]
)

"""**Load RoBERTa Model**"""

model = AutoModelForSequenceClassification.from_pretrained(
    model_name,
    num_labels=2
)

"""**Evaluation Metrics**"""

def compute_metrics(eval_pred):

    logits, labels = eval_pred

    predictions = np.argmax(logits, axis=-1)

    precision, recall, f1, _ = precision_recall_fscore_support(
        labels,
        predictions,
        average="binary"
    )

    accuracy = accuracy_score(labels, predictions)

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }

"""**Training Arguments**"""

training_args = TrainingArguments(

    output_dir="./results",

    eval_strategy="epoch",

    save_strategy="epoch",

    learning_rate=1e-5,

    per_device_train_batch_size=8,

    per_device_eval_batch_size=8,

    num_train_epochs=10,

    weight_decay=0.01,
    warmup_ratio=0.1,
    lr_scheduler_type="linear",

    load_best_model_at_end=True,

    metric_for_best_model="f1",

    logging_dir="./logs",

    logging_steps=10,
    report_to="none",
    seed=42
)

from transformers import DataCollatorWithPadding

data_collator = DataCollatorWithPadding(
    tokenizer=tokenizer
)

from transformers import Trainer, EarlyStoppingCallback

trainer = Trainer(
    model=model,
    args=training_args,

    train_dataset=train_dataset,
    eval_dataset=val_dataset,

    data_collator=data_collator,
    compute_metrics=compute_metrics,

    callbacks=[
        EarlyStoppingCallback(
            early_stopping_patience=2
        )
    ]
)

"""**Create Trainer**"""

trainer = Trainer(

    model=model,

    args=training_args,

    train_dataset=train_dataset,

    eval_dataset=test_dataset,

    compute_metrics=compute_metrics,
)

"""**Train the Model**"""

trainer.train()

"""**Evaluate**"""

results = trainer.evaluate()

print(results)

"""**Save the Model**"""

trainer.save_model("security_classifier")

tokenizer.save_pretrained("security_classifier")

"""**Test on New Reddit Posts**"""

# ============================================================
# TEST TRAINED RoBERTa MODEL ON 10,000 POSTS FROM GOOGLE DRIVE
# ============================================================

# -------------------------
# 1. Mount Google Drive
# -------------------------

from google.colab import drive
drive.mount('/content/drive')


# -------------------------
# 2. Import libraries
# -------------------------

import pandas as pd
import numpy as np
import torch
from datasets import Dataset


# -------------------------
# 3. Path of your 10K Excel file
# -------------------------

TEST_FILE = "/content/drive/MyDrive//test_10000_.xlsx"

# Change the path above according to where your file is located


# -------------------------
# 4. Load the dataset
# -------------------------

test_10k = pd.read_excel(TEST_FILE)

print("Original number of rows:", len(test_10k))
print("\nColumns:")
print(test_10k.columns)


# -------------------------
# 5. Take first 10,000 rows
# -------------------------

test_10k = test_10k.head(10000).copy()

print("\nNumber of posts to classify:", len(test_10k))


# -------------------------
# 6. Clean Title and Body
# -------------------------

test_10k["Title"] = test_10k["Title"].fillna("").astype(str)
test_10k["Body"] = test_10k["Body"].fillna("").astype(str)


# -------------------------
# 7. Combine Title + Body
# Same format used during training
# -------------------------

test_10k["text"] = (
    test_10k["Title"]
    + " [SEP] "
    + test_10k["Body"]
)


# -------------------------
# 8. Convert to HuggingFace Dataset
# -------------------------

prediction_dataset = Dataset.from_pandas(
    test_10k[["text"]],
    preserve_index=False
)


# -------------------------
# 9. Tokenization
# Same settings used during training
# -------------------------

def tokenize(batch):
    return tokenizer(
        batch["text"],
        padding="max_length",
        truncation=True,
        max_length=256
    )


prediction_dataset = prediction_dataset.map(
    tokenize,
    batched=True
)


# -------------------------
# 10. Prepare dataset for model
# -------------------------

prediction_dataset.set_format(
    type="torch",
    columns=["input_ids", "attention_mask"]
)


# -------------------------
# 11. Predict using trained RoBERTa
# -------------------------

print("\nStarting prediction...")

prediction_output = trainer.predict(prediction_dataset)

logits = prediction_output.predictions


# -------------------------
# 12. Convert logits to predicted labels
# -------------------------

predicted_labels = np.argmax(
    logits,
    axis=1
)


# -------------------------
# 13. Calculate probabilities/confidence
# -------------------------

probabilities = torch.softmax(
    torch.tensor(logits),
    dim=1
).numpy()


# -------------------------
# 14. Add results to original dataset
# -------------------------

test_10k["predicted_label"] = predicted_labels

test_10k["probability_0"] = probabilities[:, 0]

test_10k["probability_1"] = probabilities[:, 1]


# -------------------------
# 15. Add readable prediction
# -------------------------

test_10k["prediction"] = test_10k["predicted_label"].map({
    0: "Not Security/Privacy Related",
    1: "Security/Privacy Related"
})


# -------------------------
# 16. Confidence of predicted class
# -------------------------

test_10k["confidence"] = np.max(
    probabilities,
    axis=1
)


# -------------------------
# 17. Show sample results
# -------------------------

print("\nSample predictions:")

display(
    test_10k[
        [
            "Title",
            "Body",
            "predicted_label",
            "prediction",
            "probability_0",
            "probability_1",
            "confidence"
        ]
    ].head(20)
)


# -------------------------
# 18. Count predictions
# -------------------------

print("\nPrediction Counts:")
print(
    test_10k["predicted_label"].value_counts()
)


print("\nPrediction Percentages:")

print(
    test_10k["predicted_label"]
    .value_counts(normalize=True)
    .mul(100)
    .round(2)
)


# -------------------------
# 19. Security/Privacy posts only
# -------------------------

security_posts = test_10k[
    test_10k["predicted_label"] == 1
].copy()

print("\nSecurity/Privacy related posts:")
print(len(security_posts))


# -------------------------
# 20. Save ALL 10K predictions
# -------------------------

OUTPUT_FILE = (
    "/content/drive/MyDrive/Colab Notebooks/"
    "openclaw/test_10000_predictions.xlsx"
)

test_10k.to_excel(
    OUTPUT_FILE,
    index=False
)

print("\nAll predictions saved to:")
print(OUTPUT_FILE)


# -------------------------
# 21. Save ONLY Security/Privacy posts
# -------------------------

SECURITY_OUTPUT_FILE = (
    "/content/drive/MyDrive/Colab Notebooks/"
    "openclaw/security_privacy_posts_only.xlsx"
)

security_posts.to_excel(
    SECURITY_OUTPUT_FILE,
    index=False
)

print("\nSecurity/Privacy posts saved to:")
print(SECURITY_OUTPUT_FILE)


# -------------------------
# 22. Final Summary
# -------------------------

total = len(test_10k)

security_count = (
    test_10k["predicted_label"] == 1
).sum()

non_security_count = (
    test_10k["predicted_label"] == 0
).sum()


print("\n====================================")
print("FINAL CLASSIFICATION SUMMARY")
print("====================================")

print("Total Posts:", total)

print(
    "Security/Privacy Related:",
    security_count
)

print(
    "Not Security/Privacy Related:",
    non_security_count
)

print(
    "Security/Privacy Percentage:",
    round((security_count / total) * 100, 2),
    "%"
)

print("====================================")